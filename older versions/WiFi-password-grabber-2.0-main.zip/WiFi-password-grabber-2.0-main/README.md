# 🌐 WIFI Password Grabber 2.0 Beta

<p align="center">
  <img src="https://imgur.com/jEgI0ts.png" alt="WIFI Password Grabber Logo" width="400">
</p>

---

🚧 **This project is under development** 🚧

---

## 📜 Overview

This Python script extracts the SSIDs and passwords from the wireless interfaces of the machine it runs on and sends the data securely to your Discord webhook.

---

## 📷 Screenshots

### Interface and Workflow
<p align="center">
  <img src="https://imgur.com/PyUQuDQ.png" alt="Interface Screenshot" width="600">
  <img src="https://imgur.com/K8ohv5U.png" alt="Workflow Screenshot" width="600">
</p>

---

## 🔧 Usage Example
<p align="center">
  <img src="https://imgur.com/Qm9tN5c.png" alt="Usage Example Screenshot" width="600">
</p>

---

## 📌 Notes

- ❗ This script works exclusively on **Windows** machines.
- 🛡️ Please use responsibly and ensure compliance with all applicable laws.

---

👨‍💻 **Contributions:**  
Feel free to contribute or report issues by opening an [issue](#) or submitting a [pull request](#).  
